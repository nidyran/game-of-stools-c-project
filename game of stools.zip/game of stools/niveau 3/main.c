#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "definition.h" 			// les definition des structures et des constantes
#include "traitement_Monde.h" 		// les fonction applique sur le monde de jeu
#include "interface_textuelle.h" 	// les fonction d'affichage
#include "traitement_Monde.h"
#include "sauvegarde_et_chargement.h"
int main()
{
	printf("ouvrir la fenetre en plein ecran puis taper sur une touche...\n");
    getchar();
	Monde gos;
	char clan;
	initialiser(&gos); // ... Permet l'initialisation des case
	int r;
	do
	{	
		r=random_bit();
		gos.tour+=1; // incrémentation du nombre de tours
		clan=r==0?ROUGE:BLEU;
		if(gos.tour%5==0||gos.tour==1)
			menu_fichier(&clan,&gos);
        menu(clan,&gos);
        action_tour(clan,&gos);
        clan=r==0?BLEU:ROUGE;
        menu(clan,&gos);
        action_tour(clan,&gos);
	}while(game_over(&gos)==0);
	printf("\n GAME OVER \n");
}