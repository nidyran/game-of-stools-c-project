#ifndef SAUVEGARDE_ET_CHARGEMENT_H_INCLUDED
#define SAUVEGARDE_ET_CHARGEMENT_H_INCLUDED
void sauvegarde(Monde*,char);
void chargement(Monde*,char*);
#endif // SAUVEGARDE_ET_CHARGEMENT_H_INCLUDED
