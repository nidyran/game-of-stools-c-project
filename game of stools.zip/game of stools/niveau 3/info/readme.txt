Compilation : 
 gcc -Wall -Wfatal-errors  main.c interface_textuelle.c traitement_Monde.c sauvegarde_et_chargement.c -o test
Excution : 
./test 
VERSION FINAL NIVEAU 3
