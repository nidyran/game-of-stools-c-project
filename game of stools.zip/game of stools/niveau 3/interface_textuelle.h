#ifndef INTERFACE_TEXTUELLE_H_INCLUDED
#define INTERFACE_TEXTUELLE_H_INCLUDED
int random_bit();
void p2c(); // taper une touche pour continuer 
void dessiner_plateau(Monde); // une interface en mode terminal
void menu(char,Monde *); // liste des options avec lancement  des ordres 
void menu_fichier(char*,Monde *); // pour chaque 5 tour on fait appel a cette fonction de gestion sauv/charg
#endif // INTERFACE_TEXTUELLE_H_INCLUDED