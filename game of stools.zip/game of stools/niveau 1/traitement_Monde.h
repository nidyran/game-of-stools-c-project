#ifndef TRAITEMENT_MONDE_H_INCLUDED
#define TRAITEMENT_MONDE_H_INCLUDED
// j'ai utliser ces valeur de pos x/dest afin de distinger les agent qui sont immobilisé,deplacé,detruite et faire le traitement necessaire dans la fonction action tour .. 
// si dest x = -1 : Agent immobilsé
// si pos x = -2 : Agent deja deplacé dans cette tour , pour ne le deplacer pas plus qu'un fois dans un meme tour
// si pos x = -3 : Agent doit etre detruite 
// si pos x = -4 : Agent en attent de production
void initialiser(Monde *gos);
int produire_Agent(char,Monde *);
int deplacer_Agent(char ,Monde *);
int immobiliser_Agent(char clan,Monde *);
int detruire_Agent(char,Monde *);
void action_tour(char,Monde *);
int game_over(Monde *);
#endif // TRAITEMENT_MONDE_H_INCLUDED