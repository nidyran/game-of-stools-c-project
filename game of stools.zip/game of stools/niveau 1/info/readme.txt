Compilation : 
gcc -Wall -Wfatal-errors  main.c interface_textuelle.c traitement_Monde.c -o test
Excution : 
./test 
VERSION FINAL NIVEAU 1 
