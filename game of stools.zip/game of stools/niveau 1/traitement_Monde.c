#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "definition.h"
#include "interface_textuelle.h"
// les fonctions qui ne sont pas definit dans "traitement.h" sont locaux pour cette fichier ...
int tprod(char genre) // retourne le temps de production selon le genre 
{
    int t=0;
    switch(genre)
    {
        case MANANT : t=TMANANT; break;
        case GUERRIER : t=TGUERRIER; break;
        case BARON : t=TBARON; break;
        case CHATEAU :t=0; break;
    }
    return t;
}
int cprod(char genre) // retourne le temps de production selon le genre 
{
    int t=0;
    switch(genre)
    {
        case MANANT : t=CMANANT; break;
        case GUERRIER : t=CGUERRIER; break;
        case BARON : t=CBARON; break;
    }
    return t;
}
void insertion(char clan,Monde *gos,Agent *element)// insertion dans la meilleur position de la liste du clan
{
    Agent *liste=(clan==ROUGE)?gos->rouge:gos->bleu;
    Agent *prec=liste;
    char genre=element->genre;
    element->asuiv=NULL;
    if(liste==NULL)
    {
        if(clan==ROUGE)
            gos->rouge=element;
        else
            gos->bleu=element;
    }
    else
    {
        switch(genre)
        {
            case CHATEAU :
                while(liste!=NULL&&liste->genre!=BARON&&liste->genre!=GUERRIER&&liste->genre!=MANANT)
                {
                    prec=liste;
                    liste=liste->asuiv;
                }break;
            case BARON :
                while(liste!=NULL&&liste->genre!=GUERRIER&&liste->genre!=MANANT)
                {
                    prec=liste;
                    liste=liste->asuiv;
                }break;
            case GUERRIER :
                while(liste!=NULL&&liste->genre!=MANANT)
                {
                    prec=liste;
                    liste=liste->asuiv;
                }break;
            case MANANT :
                while(liste!=NULL)
                {
                    prec=liste;
                    liste=liste->asuiv;
                }break;
        }
        if(prec==NULL)
        {
            liste=element;
            liste->asuiv=NULL;
        }
        else
        {
            element->asuiv=prec->asuiv;
            prec->asuiv=element;
        }
    }
    
}
void creation(char Type,char clan,Monde *gos,int x,int y,int mode) // creation d'un agent de genre Type , clan , pos x , pos y [ mode : 0 normal , 1 :  instantné (pour l'initialisation)]
{
    AListe element=malloc(sizeof(Agent));
    gos->plateau[x][y].clan=clan;
    element->clan=clan;
    element->genre=Type;
    element->posx=element->destx=x;
    element->posy=element->desty=y;
    element->aprec=element->asuiv=element->vprec=element->vsuiv=NULL;
    element->temps=(mode==0)?tprod(Type):0;
	if(Type==CHATEAU)
        gos->plateau[x][y].chateau=element;
    else if(x!=-4)
        gos->plateau[x][y].habitant=element;
    insertion(clan,gos,element);
}

void initialiser(Monde *gos)
{
    int i,j;
	gos->tour=0; gos->tresorRouge=50; gos->tresorBleu=50; gos->rouge=gos->bleu=NULL;
	for(i=0;i<NBLIG;i++)
		for(j=0;j<NBCOL;j++)
		{
            gos->plateau[i][j].chateau=gos->plateau[i][j].habitant=NULL;
            gos->plateau[i][j].clan='-';
		}
	creation(CHATEAU,ROUGE,gos,0,0,1);
	creation(BARON,ROUGE,gos,0,1,1);
	creation(MANANT,ROUGE,gos,1,0,1);
	creation(CHATEAU,BLEU,gos,11,17,1);
	creation(BARON,BLEU,gos,11,16,1);
	creation(MANANT,BLEU,gos,10,17,1);
}
void lire_pos(int *x,int *y)// lecture d'une couple x,y controlé 
{
	do
	{
        printf(" Donner la linge du case : ");
        scanf("%d",x);
        printf(" Donner la colone du case : ");
        scanf("%d",y);
	}while(*x>12||*x<0||*y>18||*y<0);
}
int gen_voisine(int *a,int *b,char clan,Monde *gos) // si'il y a une case voisine vide on retoure la valeur 1 si non 0 [ passage par @ les valeur sont changé dans les 2 cas ]
{
	int x=clan==ROUGE?0:11,y=clan==ROUGE?0:17,i,j,ok=0;
    for(i=x-1;i<=x+1;i++)
    {
        for(j=y-1;j<=y+1;j++)
        {
            if(i>=0&&i<=11&&j>=0&&j<18&&gos->plateau[i][j].habitant==NULL&&gos->plateau[i][j].chateau==NULL)
            {
                *a=i; *b=j; ok=1;
            }
        }
    }
	return ok;
}
int  produire_Agent(char clan,Monde *gos) // menu production d'agent 
{
    int option,ok;
    int *tresor=(clan==ROUGE)?&gos->tresorRouge:&gos->tresorBleu;
    char genre;
	int x,y;
    printf(" 1 . Produire Baron\n 2 . Produire Guerrier\n 3 . Produire Manant\n");
    do
    {
		printf(" option : ");
		scanf("%d",&option);
    }while(option<1||option>3);
    switch(option)
    {
        case 1: printf("\n ->Produire Baron\n"); genre=BARON; break;
        case 2: printf("\n ->Produire Guerrier\n"); genre=GUERRIER; break;
        case 3: printf("\n ->Produire Manant\n"); genre=MANANT; break;
    }
    ok=gen_voisine(&x,&y,clan,gos);
    if(*tresor>=cprod(genre))
    {
        *tresor-=cprod(genre);
        if(ok==1)
                creation(genre,clan,gos,x,y,0);
        else 
        {
            creation(genre,clan,gos,-4,0,0);
            printf("Production mise en attente ...\n");
        }
        return 1;
    }
    else{
        printf("tresor insuffisant\n");
        return 0;
    }
}
int deplacer_Agent(char clan,Monde *gos)
{
	int x,y,x1,y1;
    printf(" Donner l'emplacement non vide de l'agent (%s) à deplacer \n",(clan==ROUGE)?"ROUGE":"BLEU");
    lire_pos(&x,&y);
    if(gos->plateau[x][y].habitant==NULL)
    {
        printf(" case (%d,%d) vide .. \nOperation impossible\n",x,y);
        return 0;
    }
    else if(gos->plateau[x][y].clan!=clan)
    {
        printf(" Agent slectionner d'autre clan \n Operation impossible\n");
        return 0;
    }
    else if(gos->plateau[x][y].chateau!=NULL)
    {
        printf(" Agent slectionner est un chateau\n Operation impossible\n");
        return 0;
    }
    printf(" Donner la nouvelle emplacement vide \n");
    lire_pos(&x1,&y1);
    if(gos->plateau[x1][y1].habitant!=NULL)
    {
        printf(" emplacement (%d,%d) non vide .. \n Operation impossible\n",x1,y1);
        return 0;
    }
    gos->plateau[x][y].habitant->destx=x1;
    gos->plateau[x][y].habitant->desty=y1;
    return 1;
}

int immobiliser_Agent(char clan,Monde *gos)
{
	int x,y;
    printf(" Donner l'emplacement non vide de l'agent (%s) à immobiliser \n",(clan==ROUGE)?"ROUGE":"BLEU");
    lire_pos(&x,&y);
    if(gos->plateau[x][y].habitant==NULL)
    {
        printf("case (%d,%d) vide .. \nOperation impossible\n",x,y);
        return 0;
    }
    else if(gos->plateau[x][y].clan!=clan)
    {
        printf("Agent slectionner d'autre clan \nOperation impossible\n");
        return 0;
    }
    gos->plateau[x][y].habitant->destx=-1;
    return 1;
}
int detruire_Agent(char clan,Monde *gos)
{
	int x,y;
	AListe element,liste=(clan==ROUGE)?gos->rouge:gos->bleu,prec=liste;
    printf(" Donner l'emplacement non vide de l'agent (%s) à detruire \n",(clan==ROUGE)?"ROUGE":"BLEU");
    lire_pos(&x,&y);
    if(gos->plateau[x][y].clan!=clan)
    {
        printf("Agent slectionner d'autre clan \nOperation impossible\n");
        return 0;
    }
    else if(gos->plateau[x][y].chateau!=NULL)
    {
        printf("case (%d,%d) occupé par un chateau .. \nOperation impossible\n",x,y);
        return 0;
    }
    else if(gos->plateau[x][y].habitant==NULL){
        printf("case (%d,%d) vide .. \nOperation impossible\n",x,y);
        return 0;
    }
    element=gos->plateau[x][y].habitant;
    gos->plateau[x][y].habitant=NULL;
    while(liste!=element)
    {
        prec=liste;
        liste=liste->asuiv;
    }
    prec->asuiv=liste->asuiv;
    free(liste);
    return 1;
}
void produire_enAttent(Monde *gos,char clan)
{
    int x,y;
    AListe element=(clan==ROUGE)?gos->rouge:gos->bleu;
    while(element!=NULL)
    {
        if(element->posx==-4&&gen_voisine(&x,&y,clan,gos)==1)
            creation(element->genre,clan,gos,x,y,0);
        element=element->asuiv;
    }
}
void action_tour(char clan,Monde *gos)
{
    int x,y,x1,y1,nx,ny,ordre;
    AListe liste=(clan==ROUGE)?gos->rouge:gos->bleu,prec=NULL;
    AListe element;
    for(x=0;x<NBLIG;x++)
		for(y=0;y<NBCOL;y++)
		{
            element=gos->plateau[x][y].habitant;
            if(element!=NULL&&element->clan==clan)
            {
                 x1=element->destx;
                 y1=element->desty;
                 if(x1>=0&&y1>=0)
                 {
                     if((x!=x1||y!=y1)&&element->posx!=-2) //deplacement ..
                     {
                        nx=(x1>x)?x+1:((x1<x)?x-1:x);
                        ny=(y1>y)?y+1:((y1<y)?y-1:y);
                        if(gos->plateau[nx][ny].clan==LIBRE&&gos->plateau[nx][ny].habitant==NULL)
                        {
                            gos->plateau[nx][ny].clan=gos->plateau[x][y].clan;
                            gos->plateau[nx][ny].habitant=element;
                            gos->plateau[x][y].habitant=NULL;
                            gos->plateau[x][y].clan=LIBRE;
                            if(nx==element->destx&&ny==element->desty&&element->genre==MANANT&&element->clan==gos->plateau[nx][ny].clan)
                            {
                                dessiner_plateau(*gos);
                                printf("\n un MANANT %s est arrivé dans la position : (%d,%d), quel ordre ?\n",(gos->plateau[nx][ny].clan==ROUGE)?"ROUGE":"BLEU",x,y);
                                printf(" 1. prendre les armes et se transformer en guerrier\n");
                                printf(" 2. récolter des ressources\n");
                                do
                                {
                                    printf(" Ordre : ");
                                    scanf("%d",&ordre);
                                }while(ordre<1||ordre>2);
                                if(ordre==1)
                                    element->genre=GUERRIER;
                                else
                                    element->destx=-1;
                            }
                            else  
                                 element->posx=-2;
                        }

                     }
                     else 
                        if(element->temps>0)
                            element->temps--;
                 }    
             }
        }
        for(x=0;x<NBLIG;x++)
            for(y=0;y<NBCOL;y++)
            {
                element=gos->plateau[x][y].habitant;
                if(element!=NULL&&element->clan==clan)
                {
                    x1=element->posx;
                    if (element->destx==-1&&element->genre==MANANT)
                    {   //un manant produit des richesses
                        if(element->clan==ROUGE)
                            gos->tresorRouge+=1;
                        else
                            gos->tresorBleu+=1;
                    }
                    else if(x1==-2)
                    {
                        element->posx=x;
                        element->posy=y;
                    }
                    else if(x1==-3)
                    {   //detruire un element
                        while(liste!=gos->plateau[x][y].habitant)
                        {
                            prec=liste;
                            liste=liste->asuiv;
                        }
                        prec->asuiv=liste->asuiv;
                        free(element);
                        gos->plateau[x][y].habitant=NULL;
                    }
                }
            }
    produire_enAttent(gos,clan);
}

int game_over(Monde *gos) // return 1 si game_over 0 si non 
{
    if(gos->rouge!=NULL&&gos->rouge->genre!=CHATEAU)
    {
        printf("clan bleu a gagne !\n");
        return 1;
    }
    if(gos->bleu!=NULL&&gos->bleu->genre!=CHATEAU)
    {
        printf("clan rouge a gagne !\n");
        return 1;
    }
    return 0;
}