#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "definition.h"
#include "interface_textuelle.h"
#include "traitement_Monde.h"
void vider(Monde *gos)
{
    int i,j;
    gos->rouge=gos->bleu=NULL;

    gos->tresorBleu=gos->tresorRouge=50;
    gos->tour=0;
    for(i=0;i<NBLIG;i++)
        for(j=0;j<NBCOL;j++)
        {
            gos->plateau[i][j].chateau=NULL;
            gos->plateau[i][j].habitant=NULL;
            gos->plateau[i][j].clan='-';
        }
}
void sauvegarde(Monde *gos,char clan)
{
    Case c;
    Agent *a=NULL;
    char nom_f[100];
    printf("Donner le nom du ficiher (.txt) : ");
    scanf("%s",nom_f);
    FILE *file;
    file=fopen(nom_f,"w");
    fprintf(file,"%c %d %d %d\n",clan,gos->tour,(clan==ROUGE)?gos->tresorRouge:gos->tresorBleu,(clan==BLEU)?gos->tresorRouge:gos->tresorBleu);
    for(int i=0;i<NBLIG;i++)
        for(int j=0;j<NBCOL;j++)
        {
            c=gos->plateau[i][j];
            if(c.chateau||c.habitant)
            {
                fprintf(file,"%c",c.clan);
                if(c.chateau)
                {
                    a=c.chateau->asuiv;
                    while(a!=NULL&&a->temps==0)
                        a=a->asuiv;
                    fprintf(file,"%c%c %d %d %d %d %d\n",'c',a?a->genre:'-',a?a->temps:0,i,j,c.chateau->destx,c.chateau->desty);
                }
                else
                    fprintf(file,"%c- %d %d %d %d %d\n",c.habitant->genre,c.habitant->temps,i,j,c.habitant->destx,c.habitant->desty);
            }

        }
    fclose(file);
    printf("\nsauvegarde termine...\n");
}
Agent *ligne_agent(char *str)
{
    char res[10];
    int i=4,p=0;
    Agent *A=NULL;
    if((str[1]==CHATEAU||str[1]==BARON||str[1]==MANANT||str[1]==GUERRIER)&&(str[0]==ROUGE||str[0]==BLEU))
    {
        A=malloc(sizeof(Agent));
        A->clan=str[0];
        A->genre=str[1];
        A->produit=str[2];
        A->asuiv=A->aprec=NULL;
        A->vsuiv=A->vprec=NULL;
        while(str[i]>='0'&&str[i]<='9')
        {
            res[p]=str[i];
            i++; p++;
        }res[p]='\0'; i++; p=0;
        A->temps=atoi(res);
        while(str[i]>='0'&&str[i]<='9')
        {
            res[p]=str[i];
            i++; p++;
        }res[p]='\0'; i++; p=0;
        A->posx=atoi(res);
        while(str[i]>='0'&&str[i]<='9')
        {
            res[p]=str[i];
            i++; p++;
        }res[p]='\0'; i++; p=0;
        A->posy=atoi(res);
        while(str[i]>='0'&&str[i]<='9')
        {
            res[p]=str[i];
            i++; p++;
        }res[p]='\0'; i++; p=0;
        A->destx=atoi(res);
        while(str[i]!='\0')
        {
            res[p]=str[i];
            i++; p++;
        }res[p]='\0'; i++; p=0;
        A->desty=atoi(res);
    }
    return A;

}
void chargement(Monde *gos,char *clan)
{
    Agent *A=NULL;
    char str[100],nom_f[10],c;
    int tr1,tr2;
    vider(gos);
    printf("Donner le nom du ficiher (.txt) : ");
    scanf("%s",nom_f);
    FILE *file=fopen(nom_f,"r");
    if(file==NULL)
        printf("lecture impossible !\n");
    else
    {
        fscanf(file,"%c %d %d %d",&c,&gos->tour,&tr1,&tr2);
        gos->tresorBleu=(c==BLEU)?tr1:tr2;
        gos->tresorRouge=(c==ROUGE)?tr1:tr2;
        while(!(feof(file)))
        {
            fgets(str,18,file); 
            A=ligne_agent(str);
            if(A!=NULL) 
            {
                gos->plateau[A->posx][A->posy].chateau=(A->genre==CHATEAU)?A:NULL;
                gos->plateau[A->posx][A->posy].habitant=(A->genre==CHATEAU)?NULL:A;
                gos->plateau[A->posx][A->posy].clan=A->clan;
                insertion(A->clan,gos,A);
                str[0]='\0';
            }
        }
        fclose(file);
        printf("\nchargement termine...\n");
        getchar();getchar();getchar();getchar();getchar();
    }
}
