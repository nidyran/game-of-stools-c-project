#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "definition.h"
#include "traitement_Monde.h"
#include "sauvegarde_et_chargement.h"
#include "interface_textuelle.h"
// les fonctions qui ne sont pas definit dans "interface_textuelle.h" ( par example : nbAgent , vide .. ) sont locaux pour cette fichier ...
void p2c() // appuyer sur une touche pour continuer
{
    printf("\n ->appuyer sur une touche pour continuer\n");
    getchar(); getchar();
    system("clear");
}
int random_bit()
{
    int r;
    do{
        r = (31+rand() % 100+rand() % 100)%2;
    }while(r>1); // on tire au hasard le groupe qui agira en premier. [ 0 Rouge , 1 Bleu ]
    return r;
}
char nbAgent(AListe liste,char Type) // ... retourne le nombre des Agent d'un type donné dans une case  ... dans ce niveau [ 1 ou 0 ]
{
    if(liste!=NULL&&liste->genre==Type&&liste->temps==0)
        return '1';
    else
        return '0';
}
void vide(char *ch,int n) // retourne une chaine vide (remplit par des espaces) de taille n
{
    int i;
    for(i=0;i<n;i++)
        ch[i]=' ';
    ch[n]='\0';
}
void representation(Case c,char res[]) // ... retourne la representation  textuelle d'une case c donné ...
{
    vide(res,5); // une chaine vide [ 5 espaces ]
    if(c.habitant!=NULL||c.chateau!=NULL)
    {
        res[0]=(c.clan==LIBRE)?' ':c.clan;
        res[1]=c.chateau?'C':' ';
        res[2]=nbAgent(c.habitant,BARON);
        res[3]=nbAgent(c.habitant,GUERRIER);
        res[4]=nbAgent(c.habitant,MANANT);
    }
    if(res[1]==' '&&res[2]=='0'&&res[3]=='0'&&res[4]=='0') // retourne une chaine vide si l'agent est cour de production
        vide(res,5);

}
void dessiner_plateau(Monde m) // ... permet la representation du l'inteface textuelle avec tt les donneés du jeu ..
{
    int i,j;
    system("clear");
	char ch[6];
	for(i=0;i<NBLIG;i++)
	{
		for(j=0;j<NBCOL;j++)
			printf("------");
		printf("-\n");
		for(j=0;j<NBCOL;j++)
		{
			representation(m.plateau[i][j],ch) ;
			printf("|%s",ch);
		}
		printf("|\n");
	}
	for(i=0;i<NBCOL;i++)
		printf("------");
	printf("-\n");
}
void menu(char clan,Monde *gos) // ... affichage de menu / affecter les actions demandeés ... (*)
{
	int ordre; // designe l'ordre choisit par le joueur
	int etat=1; // designe si l'ordre choisi est bien effectue ou non , si non en l'intrrogue pour un autre ordre
    dessiner_plateau(*gos); // une interface en mode terminal
	printf("\n Tour %d du joueur %s",gos->tour,(clan==ROUGE)?"ROUGE":"BLEU");
	printf("\n Trésor  : %d\n",clan==ROUGE?gos->tresorRouge:gos->tresorBleu);
	printf(" Chateau %s en (%d,%d), Quel ordre ?\n",(clan==ROUGE)?"ROUGE":"BLEU",clan==ROUGE?0:11,clan==ROUGE?0:17);
	printf(" 1 . Attendre \n 2 . Produire un agent \n 3 . Deplacer un agent\n 4 . Immobiliser un agent \n 5 . Detruire un agent\n");
	printf(" 6 . Transformer un MANANT en GUERRIER\n");
	do
	{
		printf(" Ordre : ");
		scanf("%d",&ordre);
	}while(ordre<1||ordre>6);
	switch(ordre)
    {
        case 1: printf("\n -> Attendre\n"); break;
        case 2: printf("\n -> Produire un agent : \n"); etat=produire_Agent(clan,gos); break;
        case 3: printf("\n -> Deplacer un agent : \n"); etat=deplacer_Agent(clan,gos); break;
        case 4: printf("\n -> Immobiliser un agent : \n");etat=immobiliser_Agent(clan,gos); break;
        case 5: printf("\n -> Detruire un agent : \n"); etat=detruire_Agent(clan,gos); break;
        case 6: printf("\n -> Transformer un MANANT en GUERRIER\n"); etat=transfer_MANANT_GUERRIER(clan,gos); break;
    }
    p2c();
    if(ordre==6||ordre==7||etat==0)
        menu(clan,gos); // on itrrogue le joueur d'un autre ordre apres l'affichage des information actuelle du jeu ou un echec d'ordre précident 
}
void menu_fichier(char *clan,Monde *gos) // ... affichage de menu / affecter les actions demandeés ...
{
    int rep;
    dessiner_plateau(*gos);
    printf("voulez-vous effectuez un sauvegarde ou un chargement ? (1 : oui | 0 : non ) : ");
    scanf("%d",&rep);
    if(rep==1)
    {
        printf("1.SAUVEGRADE\n2.CHARGEMENT\n");
        do
        {
            printf(" Ordre : ");
            scanf("%d",&rep);
        }while(rep<1||rep>2);    
        if(rep==1)
            sauvegarde(gos,*clan);
        else
            chargement(gos,clan);
    }
}